//
//  Users.swift
//  MyToDo
//
//  Created by Rahul Yadav   on 14/05/18.
//  Copyright © 2018 Ray Wenderlich. All rights reserved.
//

import UIKit
import RealmSwift

@objcMembers class Users: Object {
   dynamic var personName = ""
}
